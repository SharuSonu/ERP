step 1: npm install express mysql
step 2: npm install express mysql body-parser
step 3: change to "type": "commonjs", in package.json intead of "type": "module",