const express = require('express');
const mysql = require('mysql2/promise');
const bodyParser = require('body-parser');

const app = express();
app.use(bodyParser.json());

// Enable CORS for all requests
app.use((req, res, next) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    next();
});

const dbConfig = {
    host: 'localhost',
    user: 'root',
    password: 'Admin@12345',
    database: 'mysql' // Use a default existing database
};

app.post('/api/create-db', async (req, res) => {
    const {
        organizationName, industry, country, state,
        currency, language, timezone, isGSTRegistered, gstin, addresses
    } = req.body;

    const dbName = organizationName.toLowerCase().replace(/\s+/g, '_');
    
    let connection;
    try {
        // Connect to the default existing database
        connection = await mysql.createConnection(dbConfig);

        // Create Database if it does not exist
        await connection.query(`CREATE DATABASE IF NOT EXISTS ${dbName}`);
        // Switch to the newly created database
        await connection.changeUser({ database: dbName });

        // Create Organization Table
        await connection.query(`
            CREATE TABLE IF NOT EXISTS organization (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(255) NOT NULL,
                industry VARCHAR(255) NOT NULL,
                country VARCHAR(255) NOT NULL,
                state VARCHAR(255) NOT NULL,
                currency VARCHAR(255) NOT NULL,
                language VARCHAR(255) NOT NULL,
                timezone VARCHAR(255) NOT NULL,
                isGSTRegistered BOOLEAN NOT NULL,
                gstin VARCHAR(255)
            )
        `);

        // Insert Organization Data
        const [orgResult] = await connection.query(`
            INSERT INTO organization (
                name, industry, country, state, currency, language, timezone, isGSTRegistered, gstin
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        `, [organizationName, industry, country, state, currency, language, timezone, isGSTRegistered, gstin]);

        const orgId = orgResult.insertId;

        // Create Address Table
        await connection.query(`
            CREATE TABLE IF NOT EXISTS address (
                id INT AUTO_INCREMENT PRIMARY KEY,
                org_id INT,
                streetAddress1 VARCHAR(255) NOT NULL,
                streetAddress2 VARCHAR(255),
                city VARCHAR(255) NOT NULL,
                zip VARCHAR(255) NOT NULL,
                FOREIGN KEY (org_id) REFERENCES organization(id)
            )
        `);

        // Insert Address Data
        const addressValues = addresses.map(address => [
            orgId,
            address.streetAddress1,
            address.streetAddress2 || null,
            address.city,
            address.zip
        ]);

        if (addressValues.length > 0) {
            await connection.query(`
                INSERT INTO address (org_id, streetAddress1, streetAddress2, city, zip)
                VALUES ?
            `, [addressValues]);
        }

        // Return success message
        res.json({ success: true, message: 'Database and tables created, data inserted successfully' });
    } catch (err) {
        console.error('Error:', err);
        // Return error message
        res.status(500).json({ success: false, message: 'An error occurred' });
    } finally {
        if (connection) {
            await connection.end();
        }
    }
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
